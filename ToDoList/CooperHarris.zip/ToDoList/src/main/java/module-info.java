module csc335.ToDoList {
    requires javafx.controls;
	requires javafx.graphics;
	requires javafx.base;
    exports csc335.ToDoList;
}
