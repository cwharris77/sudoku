module csc335.BoggleGame {
    requires javafx.controls;
	requires javafx.graphics;
    exports views;
}
