/**
 * @author Cooper Harris
 * This class displays a GUI view of the model 
 * boggle
 */

package views;

import java.util.ArrayList;
import java.util.Hashtable;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import model.Boggle;

public class BoggleGUI extends Application {
	private TextArea board, attempts, resultsArea;
	private Button start, end;
	private Boggle game;
	private Font boardFont, inputFont;
	private Hashtable<String, String> dictionary;
	private Hashtable<Integer, ArrayList<String>> scoreTable;
	private final int AREA_HEIGHT = 312, AREA_WIDTH = 276;

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage stage) throws Exception {
		this.game = new Boggle();

		this.board = new TextArea();
		this.attempts = new TextArea();
		this.resultsArea = new TextArea();

		this.start = new Button("New Game");
		this.end = new Button("End Game");

		// create the dictionary hash table for the game and set game font
		dictionary = game.getDictionary("BoggleWords.txt");
		setGameFont();

		// Initialize the pieces of the game
		GridPane pane = layoutWindow(game);
		registerHandlers();

		var scene = new Scene(pane, 1200, 422);

		stage.setScene(scene);
		stage.show();
	}

	/**
	 * Sets the font of the board and user input text areas
	 */
	private void setGameFont() {
		boardFont = Font.font("System Bold", FontWeight.BOLD, 30);
		inputFont = Font.font("Symbol", 19);

	}

	/**
	 * Creates the grid pane everything is displayed on and add elements to that
	 * pane
	 * 
	 * @param game - the boggle game started
	 * @return the grid pane created
	 */
	private GridPane layoutWindow(Boggle game) {
		// create a new pane and set spacing
		GridPane pane = new GridPane();
		pane.setHgap(10);
		pane.setVgap(10);

		// create an inner grid pane to align the buttons start and end
		GridPane inner = new GridPane();
		Label enterAttempts = new Label("Enter attempts below:");
		Label results = new Label("Results:");

		inner.setHgap(10);
		inner.setVgap(10);

		inner.add(start, 1, 1);
		inner.add(end, 2, 1);
		// add the inner grid pane
		pane.add(inner, 1, 1);

		// set the board properties
		String letters = game.printTray();
		board.setText("\n\n" + letters);
		board.setMaxSize(AREA_WIDTH, AREA_HEIGHT);
		board.setFont(boardFont);
		board.setStyle("-fx-font-family: monospace");
//		board.setStyle("-fx-text-alignment: center");
		board.setEditable(false);

		// set the attempts text area properties
		attempts.setMaxSize(AREA_WIDTH, AREA_HEIGHT);
		attempts.setWrapText(true);
		attempts.setFont(inputFont);
		attempts.setStyle("-fx-border-color: green; -fx-border-width: 2px");

		// set the results text area properties
		resultsArea.setMaxSize(588, 312);
		resultsArea.setWrapText(true);
		resultsArea.setEditable(false);
		resultsArea.setFont(inputFont);

		pane.add(enterAttempts, 2, 1);
		pane.add(results, 3, 1);
		pane.add(board, 1, 3);
		pane.add(attempts, 2, 3);
		pane.add(resultsArea, 3, 3);

		return pane;
	}

	/**
	 * Private helper to print list of available fonts
	 */
	public void getFonts() {
		System.out.println(Font.getFontNames());
	}

	/**
	 * Registers the event listeners for the start and end game buttons
	 */
	private void registerHandlers() {
		start.setOnAction(new startHandler());
		end.setOnAction(new endHandler());
	}

	/**
	 * Class to set the actions taken when the start game button is pressed
	 */
	private class startHandler implements EventHandler<ActionEvent> {

		@Override
		public void handle(ActionEvent event) {
			// Create a new game and display the new board
			game = new Boggle();

			String letters = game.printTray();
			board.setText("\n\n" + letters);

			// allow the user to enter attempts again
			attempts.setEditable(true);

			// remove the old game text
			attempts.clear();
			resultsArea.clear();
		}

	}

	/**
	 * Class to set the actions taken when the end game button is pressed
	 */
	private class endHandler implements EventHandler<ActionEvent> {

		@Override
		public void handle(ActionEvent event) {
			// don't allow the user to edit or add to their attempts
			attempts.setEditable(false);

			// get a string of all their attempts for scoring
			String attemptsWords = attempts.getText();
			String[] attemtpsArray = attemptsWords.split("\\s+");

			// An arraylist to be passed to the Boggle method getScore
			ArrayList<String> userWords = new ArrayList<>();

			for (String word : attemtpsArray) {
				userWords.add(word.toLowerCase());
			}

			// A hashtable containing different parts of the score
			scoreTable = game.getScore(userWords, dictionary);

			// format the score
			String scores = scoreText();

			resultsArea.setText(scores);
		}

		/**
		 * @return A string that contains all pieces of the score
		 */
		private String scoreText() {
			// the list of user entered words that were in the tray
			String foundWords = scoreTable.get(1).toString();
			// the list of words the user entered that were not in the tray
			String incorrectWords = scoreTable.get(2).toString();
			// all words in the tray that the user did not enter
			String missedWords = scoreTable.get(3).toString();

			String s = "Your score: " + scoreTable.get(0).get(0);
			s += "\n\nWords you found:\n" + foundWords.substring(1, foundWords.length() - 1) + "\n";
			s += "\nIncorrect words:\n" + incorrectWords.substring(1, incorrectWords.length() - 1) + "\n";
			s += "\nYou could have found " + scoreTable.get(3).size() + " more words:\n"
					+ missedWords.substring(1, missedWords.length() - 1) + "\n";

			return s;
		}
	}

}
