module csc335.TempConverter {
    requires javafx.controls;
	requires javafx.graphics;
    exports csc335.TempConverter;
}
